<?php include 'template/header.php' ?>
<?php include 'template/navbar.php' ?>

<?php 
			include_once('db.php');
			
			$sql  = 'SELECT * FROM `users`';
			$resultSet = $con->query($sql);
?>

		

<?php  if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 1) { ?>
<section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		<div class="crumbs">
         <ul>
           <li><a href="index.php">Home</a></li>
           <li><a href="notify.php">Notify</a></li>
         </ul>
      </div>
		<div id="main-content">

			<div class="container">
						<h3 align="center">NOTIFY CUSTOMER</h3>
						<br />
						<div class="table-responsive">
						<table class="table table-bordered table-striped">
								<tr>
									<th>Customer Name</th>
									<th>Email</th>
									
								</tr>

							
						<?php foreach($resultSet as $r){ ?>
						<tr>
							<td><?php echo $r['name']; ?></td>
							
							<td><?=$r['email']?></td>
							
						</tr>
						<?php } ?>
						</table>

						</div>
					


					
						<div class="row">
							<div class="col-md-8" style="margin:0 auto; float:none;">
								<h3 align="center">Send an Email on Form Submission using PHP with PHPMailer</h3>
								<br />
								
								<form method="post">
									<div class="form-group">
										<label>Enter Name</label>
										<input type="text" name="name" placeholder="Enter Name" class="form-control" value= "">

									</div>
								
									<div class="form-group">
										<label>Enter Subject</label>
										<input type="text" name="subject" class="form-control" placeholder="Enter Subject" value="">
									</div>
									<div class="form-group">
										<label>Enter Message</label>
										<textarea name="message" class="form-control" placeholder="Enter Message"></textarea>
									</div>
									<div class="form-group" align="center">
										<button type="button" name="bulk_email" class="btn btn-info email_button" id="bulk_email" data-action="bulk">Send All</button>
									</div>
								</form>
							</div>
						</div>
				
			</div>



		</div>
	</div>
</section>
<?php }else{ header('location:login.php');} ?>
<?php include 'template/footer.php' ?>