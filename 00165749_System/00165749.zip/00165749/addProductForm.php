	
	<?php include 'template/header.php'; ?>
    <!-- Navigation -->
    <?php include 'template/navbar.php'; ?>
    <?php  if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 1) { ?>
    <!-- Page Content -->
 <section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		<div class="crumbs">
	      <ul>
	        <li><a href="index.php">Home</a></li>
	        <li><a href="addProduct.php">Add product</a></li>
	      </ul>
  		</div>
		<div id="main-content">
	    <div class="container">

	      <div class="row ">

	        

	        <div class="col-lg-9 regform">
				<form action="addProduct.php" method="POST" enctype="multipart/form-data" class="frm">
					<div class="form-group">
						<label for="email">Product Name</label>
						<input type="text" name="name" class="form-control" id="name" placeholder="Product name">
					</div>
					<div class="form-group">
						<label for="email">Product Description</label>
						<textarea name="description" class="form-control" id="name" placeholder="Product descripction" ></textarea>
					</div>
					<div class="form-group">
						<label for="pass">Price</label>
						<input type="text" name="price" class="form-control" id="price" placeholder="Price">
					</div>
					<div class="form-group">
						<label for="pass">Quantity</label>
						<input type="text" name="quantity" class="form-control" id="quantity" placeholder="quantity">
					</div>
					<div class="form-group">
						<label for="pass">Image</label>
						<input type="file" name="fileToUpload" class="form-control" id="fileToUpload" placeholder="Image to upload">
					</div>

					 <div class="form-group">
					  <label for="sel1">Select Category:</label>
						  <select class="form-control" name="Category">
						    <option value="fast_food">Select Category</option>
						    <option value="fast_food">Fast food</option>
						    <option value="drinks" >Drink</option>
						    <option value="sea_food">Sea food</option>
						    
						  </select>
					</div> 
								
				  
				  <button type="submit" class="btn btn-primary">Submit</button>
			</form>
	     
	        </div>
	        <!-- /.col-lg-9 -->
	      </div>
	      <!-- /.row -->
	    </div>
	  
      </div>
    <!-- /.container -->
    </div>

</section>
<?php }else{ header('location:login.php');} ?>

    <!-- Footer -->
	<?php include 'template/footer.php'; ?>