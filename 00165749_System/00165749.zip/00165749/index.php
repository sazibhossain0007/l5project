<?php include 'template/header.php' ?>
<?php include 'template/navbar.php' ?>
<?php include 'template/slider.php' ?>

<section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		<div class="crumbs">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="index.php">Home</a></li>
			</ul>
		</div>
		<div id="main-content">




		</div>
	</div>
</section>


<?php include 'template/footer.php' ?>