<?php include_once 'db.php';
?>
<?php
		$id = $_GET['id'];
        //$select_data = "SELECT * FROM `forum_comment` where id =$id";
        //$run_data = mysqli_query($con,$select_data);
        $delt ="DELETE FROM `forum_comment` WHERE id= $id";
        $con->query($delt);
        header('location:forum.php');
        

?>

