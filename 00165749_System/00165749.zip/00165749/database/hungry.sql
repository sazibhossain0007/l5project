-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2018 at 06:09 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hungry`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `staff_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `staff_name`, `staff_id`) VALUES
(12, 'John', '09CS68'),
(13, 'Ponting', '09CS70'),
(14, 'Sazib', 's001'),
(15, 'sumon', 's008'),
(16, 'Muzahid', 'M001');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

CREATE TABLE `attendance_records` (
  `id` int(11) NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `staff_id` varchar(255) NOT NULL,
  `attendance_status` varchar(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance_records`
--

INSERT INTO `attendance_records` (`id`, `staff_name`, `staff_id`, `attendance_status`, `date`) VALUES
(19, 'John', '09CS68', 'Present', '2018-09-06'),
(20, 'Ponting', '09CS70', 'Absent', '2018-09-06'),
(21, 'John', '09CS68', 'Absent', '2018-09-30'),
(22, 'Ponting', '09CS70', 'Absent', '2018-09-30'),
(23, 'Sazib', 's001', 'Absent', '2018-09-30'),
(24, 'sumon', '', 'Present', '2018-10-01'),
(25, 'sumon', '', 'Present', '2018-10-01'),
(26, 'sumon', '', 'Present', '2018-10-01'),
(27, 'sumon', '', 'Present', '2018-10-01'),
(32, 'John', '09CS68', 'Present', '2018-10-02'),
(33, 'Ponting', '09CS70', 'Present', '2018-10-02'),
(34, 'Sazib', 's001', 'Present', '2018-10-02'),
(35, 'sumon', 's008', 'Present', '2018-10-02'),
(36, 'John', '09CS68', 'Present', '2018-10-03'),
(37, 'Ponting', '09CS70', 'Absent', '2018-10-03'),
(38, 'Sazib', 's001', 'Absent', '2018-10-03'),
(39, 'sumon', 's008', 'Present', '2018-10-03'),
(40, 'John', '09CS68', 'Present', '2018-10-05'),
(41, 'Ponting', '09CS70', 'Present', '2018-10-05'),
(42, 'Sazib', 's001', 'Absent', '2018-10-05'),
(43, 'sumon', 's008', 'Present', '2018-10-05'),
(44, 'John', '09CS68', 'Present', '2018-10-24'),
(45, 'Ponting', '09CS70', 'Present', '2018-10-24'),
(46, 'Sazib', 's001', 'Present', '2018-10-24'),
(47, 'sumon', 's008', 'Present', '2018-10-24');

-- --------------------------------------------------------

--
-- Table structure for table `forum_comment`
--

CREATE TABLE `forum_comment` (
  `id` int(11) NOT NULL,
  `description` varchar(200) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_comment`
--

INSERT INTO `forum_comment` (`id`, `description`, `post_date`, `user_id`, `post_id`) VALUES
(1, 'this is 1st comment.', '2018-10-24 04:05:01', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `forum_post`
--

CREATE TABLE `forum_post` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_post`
--

INSERT INTO `forum_post` (`id`, `title`, `description`, `post_date`, `user_id`) VALUES
(1, 'this is 1st post', 'i love food', '2018-09-21 15:40:12', 9),
(2, '2nd comment', 'i love to eat', '2018-09-30 01:19:43', 9),
(3, 'ttt', 'aaaaaaaaa', '2018-10-04 07:16:31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `order_status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`order_id`, `p_id`, `c_id`, `quantity`, `total_price`, `order_status`) VALUES
(1, 11, 9, 5, 75, 'done'),
(4, 11, 9, 1, 15, 'done'),
(5, 12, 9, 5, 1100, 'done'),
(6, 12, 9, 5, 1100, 'done'),
(7, 12, 9, 1, 235, 'done'),
(8, 12, 9, 1, 235, 'done'),
(9, 15, 9, 1, 35, 'reject'),
(10, 11, 1, 1, 15, 'done'),
(11, 12, 9, 1, 220, 'done'),
(12, 12, 9, 1, 220, 'done'),
(13, 12, 9, 1, 220, 'reject'),
(14, 13, 10, 1, 470, 'pending'),
(15, 15, 10, 1, 35, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` varchar(250) NOT NULL,
  `image` varchar(200) NOT NULL,
  `category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `quantity`, `description`, `image`, `category`) VALUES
(12, 'Shorma', 220, 20, 'this is pasta	', 'upload_images/4.jpg', 'fast_food'),
(13, 'Octopas Curry', 250, 200, '					hhhhhhhhhhhhhhhhhhhhhh', 'upload_images/sea1.jpg', 'sea_food'),
(15, 'pepsi', 35, 100, 'great drinks			', 'upload_images/can-real-sugar-reg.png', 'drinks'),
(16, 'Coca Cola', 45, 500, 'Coca-Cola, or Coke is a carbonated soft drink manufactured by The Coca-Cola Company. Originally intended as a patent medicine, it was invented in the late 19th century by John Pemberton', 'upload_images/coca.jpg', 'drinks'),
(17, 'Spicey Fish Fry', 300, 120, 'most fish contain trace amounts of mercury, but a handful have especially high levels which should be avoided, especially for pregnant women and young children.  To avoid fish high in mercury, avoid consuming these fish regularly', 'upload_images/sea2.jpg', 'sea_food'),
(20, 'Cheer Wine', 55, 100, 'gg', 'upload_images/51jnf+uDQXL._SY355_.jpg', 'drinks');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(36) NOT NULL,
  `email` varchar(100) NOT NULL,
  `postal_address` varchar(100) NOT NULL,
  `post_code` int(5) NOT NULL,
  `password` varchar(15) NOT NULL,
  `role` int(2) NOT NULL DEFAULT '0' COMMENT '0-user, 1-admin',
  `regTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `postal_address`, `post_code`, `password`, `role`, `regTime`) VALUES
(1, 'sazib', 'sazib50hossain82@gmail.com', 'dhanmondi', 1206, '123', 0, '2018-10-02 21:34:11'),
(8, 'Admin', 'admin@hb.com', 'Dhanmondi', 1204, '123', 1, '2018-04-22 19:18:21'),
(9, 'User', 'user1@gmail.com', 'uttra', 1206, '123', 0, '2018-04-22 19:21:32'),
(10, 'sazib Hossain', 'sazib@gmail.com', 'dhanmondi', 1204, '123', 0, '2018-10-24 07:28:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forum_comment`
--
ALTER TABLE `forum_comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forum_post`
--
ALTER TABLE `forum_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `attendance_records`
--
ALTER TABLE `attendance_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `forum_comment`
--
ALTER TABLE `forum_comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `forum_post`
--
ALTER TABLE `forum_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
