<?php include 'template/header.php' ?>
<?php include 'template/navbar.php' ?>
<?php  if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 1) { ?>
<section id="container" class="sub-page">
    <div class="wrap-container zerogrid">
        <div class="crumbs">
         <ul>
           <li><a href="index.php">Home</a></li>
           <li><a href="attendence.php">Attendence</a></li>
         </ul>
      </div>
        <div id="main-content">
         <div class="container">
            <h2><div class="well text-center">STAFF ATTENDENCE </div></h2>


         <?php
            include("db.php");
            
               $flag=0;
               $update=0;
               if(isset($_POST['Update'])){
            	
            		 foreach($_POST['attendance_status'] as $id=>$attendance_status)
            		   {
            			$date=$_POST['date'][$id];
               
            			$staff_name=$_POST['staff_name'][$id];
            			$staff_id=$_POST['staff_id'][$id];
            			
            			$result=mysqli_query($con,"update attendance_records set staff_name='$staff_name',staff_id='$staff_id',attendance_status='$attendance_status',date='$date'
            			where date='$date' and  staff_id='$staff_id';
            			
            			");
            			if($result)
            			{
            			$update=1;	
            			}	
            					
            			   
            		   }   
            	   
            	   
               }
               if(isset($_POST['submit']))
               {
            	   $date=date("Y-m-d");
            	   
            
            	   $records=mysqli_query($con,"select * from attendance_records where date='$date'");;
            	   $num=mysqli_num_rows($records);
            	   
            	   if($num)
            	   {
            		 
                    		 
            	   }
            	   else
            	   {	   
            		   foreach($_POST['attendance_status'] as $id=>$attendance_status)
            		   {
            			$staff_name=$_POST['staff_name'][$id];
            			$staff_id=$_POST['staff_id'][$id];
            			
            			
            			$result=mysqli_query($con,"insert into attendance_records(staff_name,staff_id,attendance_status,date)values('$staff_name','$staff_id','$attendance_status','$date')");
            			if($result)
            			{
            			$flag=1;	
            			}	
            					
            			   
            		   }
            	   }
               }	   
            
            ?>
            <div class="panel panel-default">
               <div class="panel panel-heading">
                  <h2>
                     <a class="btn btn-success" href="add.php">Add Staff </a>
                     <a class="btn btn-info pull-right" href="view_all.php"> View All </a>
                  </h2>
                  <?php if($flag){ ?>
                  <div class="alert alert-success">
                     Attendance Data Inserted Successfully
                  </div>
                  <?php } ?>
                  <?php if($update){ ?>
                  <div class="alert alert-success">
                     Staff Attandance updated successfully.
                  </div>
                  <?php } ?>
                  <H3>
                     <div class="well text-center">Date:<?php echo date("Y-m-d"); ?>  </div>
                  </H3>
                  <div class="panel panel-body">
                     <form action="attendance.php" method="Post">
                        <table class="table table-striped">
                           <tr>
                              <th>#serial Number</th>
                              <th>Staff Name</th>
                              <th>Staff Id</th>
                              <th> Attendance Status </th>
                           </tr>
                           <?php 
                              $date=date("Y-m-d");
                              $result=mysqli_query($con,"SELECT attendance.staff_name,attendance.staff_id,attendance_records.attendance_status FROM attendance LEFT JOIN attendance_records ON attendance.staff_id = attendance_records.staff_id and date='$date'");
                              $serialnumber=0;
                              $counter=0;
                              while($row=mysqli_fetch_array($result))
                              {
                              $serialnumber++;
                              
                              
                              ?>
                           <tr>
                              <td> <?php echo $serialnumber; ?>  </td>
                              <td> <?php echo $row['staff_name']; ?>  
                                 <input type="hidden" value="<?php echo $row['staff_name']; ?>" name="staff_name[]">
                              </td>
                              <td> <?php echo $row['staff_id']; ?>  
                                 <input type="hidden" value="<?php echo $row['staff_id']; ?>" name="staff_id[]">
                              </td>
                              <td>
                                 <input type="radio" name="attendance_status[<?php echo $counter; ?>]" value="Present"
                                    <?php if($row['attendance_status']=="Present"){ 	
                                       echo "checked=checked";
                                       }
                                       ?>
                                    required >Present
                                 <input type="radio" name="attendance_status[<?php echo $counter; ?>]" value="Absent" 
                                    <?php if($row['attendance_status']=="Absent"){ 	
                                       echo "checked=checked";
                                       }
                                       ?>
                                    required>Absent
                              </td>
                           </tr>
                           <?php 
                              $counter++;
                              }
                              ?>
                        </table>
                        <input type="submit" name="submit" value="Submit" class="btn btn-primary">	

                     </form>
                  </div>
               </div>
         </div>
         </div>
      </div>
   </div>
</section>
<?php }else{ header('location:login.php');} ?>


<?php include 'template/footer.php' ?>