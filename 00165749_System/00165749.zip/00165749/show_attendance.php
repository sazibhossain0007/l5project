<?php include 'template/header.php' ?>
<?php include 'template/navbar.php' ?>

<?php  if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 1) { ?>
<section id="container" class="sub-page">
   <div class="wrap-container zerogrid">
      <div class="crumbs">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="add.php">Attendence</a></li>
      </ul>
   </div>
      <div id="main-content">


       <div class="container">
         <h2><div class="well text-center">STAFF ATTENDANCE</div></h2>

         <?php
            include("db.php");
            
         ?>
         <div class="panel panel-default">
            <div class="panel panel-heading">
               <h2>
                  <a class="btn btn-success" href="add.php">Add Staff </a>
                  <a class="btn btn-info pull-right" href="attendance.php"> Back </a>
               </h2>
               <div class="panel panel-body">
                  <form action="attendance.php" method="Post">
                     <table class="table table-striped">
                        <tr>
                           <th>#Serial Number</th>
                           <th>Staff Name</th>
                           <th>Staff Id</th>
                           <th>Attendance Status </th>
                        </tr>
                        <?php 
                           $result=mysqli_query($con,"select * from attendance_records where date='$_POST[date]'");
                              $serialnumber=0;
                           $counter=0;
                           while($row=mysqli_fetch_array($result))
                           {
                           $serialnumber++;
                           ?>
                        <tr>
                           <td> <?php echo $serialnumber; ?>  </td>
                           <td> <?php echo $row['staff_name']; ?>    <input type="hidden" value="<?php echo $row['staff_name']; ?>" name="staff_name[]">
                           </td>
                           <td> <?php echo $row['staff_id']; ?> 
                              <input type="hidden" value="<?php echo $row['staff_id']; ?>" name="staff_id[]">
                              <input type="hidden" value="<?php echo $row['date']; ?>" name="date[]">
                           </td>
                           <td> 
                              <input type="radio" name="attendance_status[<?php echo $counter; ?>]" 
                                 <?php if($row['attendance_status']=="Present")
                                    echo "checked=checked";
                                    ?>
                                 value="Present" >Present
                              <input type="radio" name="attendance_status[<?php echo $counter; ?>]" value="Absent"
                                 <?php if($row['attendance_status']=="Absent")
                                    echo "checked=checked";
                                    ?>
                                 >Absent
                           </td>
                        </tr>
                        <?php 
                           $counter++;
                           }
                           ?>
                     </table>
                     <input type="submit" name="Update" value="Update" class="btn btn-primary"> 
                  </form>
               </div>
            </div>
         </div>

      </div>
   </div>
</section>

<?php }else{ header('location:login.php');} ?>

<?php include 'template/footer.php' ?>