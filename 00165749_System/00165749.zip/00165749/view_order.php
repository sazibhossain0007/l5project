<?php include 'template/header.php' ?>
<?php include 'template/navbar.php' ?>

<?php 
			include_once('db.php');
			
			$sql  = "SELECT * FROM products where order_status='pending' ";
			$resultSet = $con->query($sql);
?>
<?php  if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 1) { ?>
<section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		
		<div id="main-content">

			
			<div class="container">
						<h3 align="center">Pending Order</h3>
						<br />
						<div class="table-responsive">
						<table class="table table-bordered table-striped">
								<tr>
									<th>Order id</th>
									<th>Product id</th>
									<th>Customer id</th>
									<th>Quantity</th>
									<th>Total price</th>
									<th>Order status </th>
								</tr>

							
						<?php foreach($resultSet as $r){ ?>
						<tr>
							<td><?php echo $r['order_id']; ?></td>
							
							<td><?=$r['p_id']?></td>
							<td><?=$r['c_id']?></td>
							<td><?=$r['quantity']?></td>
							<td><?=$r['total_price']?></td>
							<td><?=$r['total_price']?></td>
							
						</tr>
						<?php } ?>
						</table>

						</div>	
							
			</div>


		</div>
	</div>
</section>
<?php }else{ header('location:login.php');} ?>
<?php include 'template/footer.php' ?>