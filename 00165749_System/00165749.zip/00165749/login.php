	
	<?php include 'template/header.php'; ?>
	<?php include 'template/navbar.php'; ?>

	
    <!-- Navigation -->
    
    <!-- Page Content -->
    <section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		<div class="crumbs">
         <ul>
           <li><a href="index.php">Home</a></li>
           <li><a href="login.php">Log in</a></li>
         </ul>
      </div>
		<div id="main-content">
        
        <!-- /.col-lg-3 -->



        <div class="col-lg-12 ">
        	 <div class="col-lg-3" ></div>
			
			<div class="col-lg-6 log">
			<?php 
				if(isset($_COOKIE['loginAttempt']) && $_COOKIE['loginAttempt'] == true){ 
					echo '<h2 style="color:red;" >You are blocked for 5 minute</h2>';
				}else{
			?>
			<form action="loginChecker.php" method="POST" class="frm">
					<?php if(isset($_GET['msg'])){ ?>
						<div class="alert alert-danger">
						<?php echo $_GET['msg'];?>
							</div>
					<?php } ?>
							  
				 <div class="form-group email">
					<label for="email">Email</label>
					<input type="email" name="email" class="form-control login" id="email" placeholder="Email">
					<p class="email-error hide" style="color:red">You must enter email</p>
				</div>
				<div class="form-group">
					<label for="pass">Password</label>
					<input type="password" name="pass" class="form-control" id="pass" placeholder="Password">
					<p class="pass-error hide" style="color:red">Please type your password</p>
				</div>
				
			
			  
				  <button type="submit" onclick="return formValidate();" class="btn btn-primary email">Submit</button>
				  <a href="reg_form.php" style="color:red;">Want to be a member? CLICK HERE</a>
			</form>
		<?php } ?>
		</div>
	
     
        </div>
        <!-- /.col-lg-9 -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container -->
    </div>

</section>
    <script>
			function formValidate(){
				//alert($('#user_name').val());
				if($('#email').val() == ''){
					$('.email-error').removeClass('hide');
					returnResult = false;
				}else{
					$('.email-error').addClass('hide');
					returnResult = true;
				}
				if($('#phone').val() == ''){
					$('.phone-error').removeClass('hide');
					returnResult = false;
				}else{
					$('.phone-error').addClass('hide');
					returnResult = true;
				}

				
				

				return returnResult;
			
			}
		

		
	</script>

    <!-- Footer -->
<?php include 'template/footer.php'; ?>