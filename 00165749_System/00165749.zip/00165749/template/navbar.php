<div class="wrap-body ">
	<!--///////////////////////////////////////Top-->
	<div class="top">
		<div class="zerogrid">
			<ul class="number f-left">
				<li class="mail"><p>ContacUst@Gmail.com</p></li>
				<li class="phone"><p>01817000040</p></li>
			</ul>
			<ul class="top-social f-right">
				<li><a href="#"><i class="fa fa-twitter"></i></a></li>
				<li><a href="#"><i class="fa fa-facebook"></i></a></li>
				<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
				<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
				<li><a href="#"><i class="fa fa-instagram"></i></a></li>
			</ul>
		</div>
	</div>
	<!--////////////////////////////////////Header-->
	<header>
		<div class="zerogrid">
			<center><div class="logo"><img src="images/logo.png"></div></center>
		</div>
	</header>
	<div class="site-title">
		<div class="zerogrid">
			<div class="row">
				<h2 class="t-center">Truely the best restaurant in town - Dhaka</h2>
			</div>
		</div>
	</div>
    <!--//////////////////////////////////////Menu-->
    <a href="#" class="nav-toggle">Toggle Navigation</a>
    <nav class="cmn-tile-nav">
		<ul class="clearfix">
			<li class="colour-1"><a href="index.php">Home</a></li>

			<?php  if(isset($_SESSION['loggedIn'])  && $_SESSION['user_role'] == 0) { ?>
			
			<li class="colour-2"><a href="menu.html">News</a></li>
			
			<li class="colour-4"><a href="archive.html">Gellery</a></li>
			<li class="colour-5 "><a href="menu.php">menu</a></li>
			<li class="colour-5 "><a href="cart.php">cart</a></li>
			<li class="colour-5"><a href="forum.php">Blog</a></li>
			<li class="colour-5"><a href="userProfile.php"><?=$_SESSION['user_name']?></a></li>
			<li class="colour-5"><a href="logout.php">Log out</a></li>

			<?php }else if(isset($_SESSION['loggedIn'])==true  && $_SESSION['user_role'] == 1){ ?>
				<li class="colour-3"><a href="addProductForm.php">Add product</a></li>
				<li class="colour-3"><a href="order_view.php">Order</a></li>
				<li class="colour-6"><a href="attendance.php">Attendence</a></li>
				<li class="colour-6"><a href="notify.php">Notify</a></li>
				<li class="colour-5"><a href="forum.php">Blog</a></li>

				<li class="colour-5"><a href="userProfile.php"><?=$_SESSION['user_name']?></a></li>
				<li class="colour-5"><a href="logout.php">Log out</a></li>

			<?php }else{ ?>
			<li class="colour-3"><a href="location.html">Location</a></li>
			<li class="colour-6"><a href="staff.html">news</a></li>
			<li class="colour-6"><a href="staff.html">gellery</a></li>
			<li class="colour-6"><a href="staff.html">Our Staff</a></li>
			<li class="colour-6"><a href="staff.html">about us</a></li>
			<li class="colour-6"><a href="staff.html">FOOD</a></li>
			<li class="colour-8"><a href="login.php">Log in</a></li>

			<?php } ?>
			
			


			
		</ul>
    </nav>