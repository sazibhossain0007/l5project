<?php
	session_start();
	if(!isset($_SESSION['loginAttemptCount'])){
		$_SESSION['loginAttemptCount'] = 0;
	}
	//Login Checker
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	//echo $pass;
	include_once('db.php');


	
	$sql  = "SELECT * FROM `users` WHERE `email`='$email' AND `password` = '$pass'";

	$result = $con->query($sql);
	if($result->num_rows > 0){// IF user exist in database


		
			foreach($result AS $row){
				$_SESSION['user_id'] = $row['id'];
				$_SESSION['user_name'] = $row['name'];
				$_SESSION['user_role'] = $row['role'];
			}
			$_SESSION['loggedIn'] = true;
			unset($_SESSION['loginAttemptCount']);
			header('Location:index.php');
		

		
		}else{
			$_SESSION['loginAttemptCount']++;
			if($_SESSION['loginAttemptCount'] >= 300){
				setcookie("loginAttempt", true, time() + (60*5)); 
		}
		
		header('Location:login.php?msg=Username or password invalid');
	}




?>