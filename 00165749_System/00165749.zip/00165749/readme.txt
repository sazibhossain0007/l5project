Instraction for using this system


1. After extracting the folder move it into folder: xampp\htdocs

2. Create a database named hungry

3. Import hungry.sql file from database folder

4. For logged in as a admin use


email: admin@hb.com
password: 123

5. For logged in as a user use

email: user1@gmail.com
password:123