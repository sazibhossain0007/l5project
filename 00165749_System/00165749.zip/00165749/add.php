<?php include 'template/header.php' ?>
<?php include 'template/navbar.php' ?>
<?php  if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 1) { ?>
<section id="container" class="sub-page">
    <div class="wrap-container zerogrid">
        <div class="crumbs">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="add.php">Attendence</a></li>
      </ul>
    </div>
        <div id="main-content">
         <div class="container">
         <h2><div class="well text-center">STAFF ATTENDENCE </div></h2>

         <?php
            
            include("db.php");
            $flag=0;
            
             if(isset($_POST['submit']))
            	 {
            		$result=mysqli_query($con,"insert into attendance(staff_name,Staff_Id)values('$_POST[name]','$_POST[Staff_Id]')");	
            		
            	    if($result)
                 {
            	     $flag=1;	
            	    }		
            		
            	 }
          
          ?>
         <div class="panel panel-default">
            <?php if($flag){ ?>
            <div class="alert alert-success">
               <strong>!success</strong> attendance data successfully inserted;
            </div>
            <?php } ?>
            <div class="panel-heading">
               <h2>
                  <a class="btn btn-success" href="add.php"> Add Staff</a>
                  <a class="btn btn-info pull-right" href="attendance.php"> Back </a>
               </h2>
            </div>
            <div class="panel-body">
               <form action="add.php" method="post">
                  <div class="form-group">	
                     <label for="name">Staff Name </label>
                     <input type="text" name="name" id="name" class="form-control" required>
                  </div>
                  <div class="form-group">	
                     <label for="Staff_Id">Staff Id </label>
                     <input type="text" name="Staff_Id" id="Staff_Id" class="form-control" required>
                  </div>
                  <div class="form-group">	
                     <input type="submit" name="submit" value="Submit"  class="btn btn-primary" required>
                  </div>
               </form>
            </div>
         </div>
         </div>
      </div>
   </div>
</section>
<?php }else{ header('location:login.php');} ?>
<?php include 'template/footer.php' ?>