<?php include 'template/header.php' ?>
<?php include 'template/navbar.php' ?>
<?php include 'db.php' ?>
<section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		
		<div id="main-content">

<?php 
if(isset($_POST['c_confirm'])){

    $pid=$_POST['product_id'];
    $cid=$_SESSION['user_id'];
    $pqnty=$_POST['item_quantity'];
    $ptotal=$_POST['total'];
   

$sql  = "INSERT INTO `order_details`( `p_id`, `c_id`, `quantity`, `total_price`, `order_status`) VALUES ($pid,$cid,$pqnty,$ptotal,'pending')";
echo "<h2>Thank you For receiving our service </h2>";
$result = $con->query($sql);
if(!$result){
    echo "<br><br><br>".mysqli_error($con);
}
}
 ?>
		</div>
	</div>
</section>

   

<?php include 'template/footer.php' ?>