<?php include 'template/header.php' ?>
<?php include 'template/navbar.php' ?>
<?php include 'db.php' ?>
<?php
    

    if (isset($_POST["add"])){
        if (isset($_SESSION["cart"])){
            $item_array_id = array_column($_SESSION["cart"],"product_id");
            if (!in_array($_GET["id"],$item_array_id)){
                $count = count($_SESSION["cart"]);
                $item_array = array(
                    'product_id' => $_GET["id"],
                    'item_name' => $_POST["hidden_name"],
                    'product_price' => $_POST["hidden_price"],
                    'item_quantity' => $_POST["quantity"],
                );
                $_SESSION["cart"][$count] = $item_array;
                echo '<script>window.location="Cart.php"</script>';
            }else{
                echo '<script>alert("Product is already Added to Cart")</script>';
                echo '<script>window.location="Cart.php"</script>';
            }
        }else{
            $item_array = array(
                'product_id' => $_GET["id"],
                'item_name' => $_POST["hidden_name"],
                'product_price' => $_POST["hidden_price"],
                'item_quantity' => $_POST["quantity"],
            );
            $_SESSION["cart"][0] = $item_array;
        }
    }

  
?>
<?php  if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 0) { ?>
<section id="container" class="sub-page">
    <div class="wrap-container zerogrid">
        <div class="crumbs">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
            </ul>
        </div>
        <div id="main-content">

            <div class="container">
                <div class="col-lg-3">
                    <h2>Category</h2>
                      <div class="list-group">
                        <a href="catergory_wise_view.php?category=fast_food" class="list-group-item">Fast food</a>
                        <a href="catergory_wise_view.php?category=drinks" class="list-group-item">Drink</a>
                        <a href="catergory_wise_view.php?category=sea_food" class="list-group-item">Sea food</a>
                     </div>
                </div>
                <div class="col-lg-9">
                    
                

                 <?php
                     $query = "SELECT * FROM products ORDER BY id ASC ";
                     $result = mysqli_query($con,$query);
                    if(mysqli_num_rows($result) > 0) {

                     while ($row = mysqli_fetch_array($result)) {

                    ?>
                                                
                    <div class="col-md-4" style="text-align: center;" >

                          <form method="post" action="menu.php?action=add&id=<?php echo $row["id"]; ?>">

                                <div class="product" style="margin-top: 20px">
                                      <img src="<?php echo $row["image"]; ?>" class="img-responsive" style="height: 200px; width: 260px; background-size: cover;" >
                                        <h5 class="text-info"><?php echo $row["name"]; ?></h5>
                                        <h5 class="text-danger"><?php echo $row["price"]; ?></h5>
                                        <input type="text" name="quantity" class="form-control" value="1">
                                        <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>">
                                         <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>">
                                         <input type="submit" name="add" style="margin-top: 5px;" class="btn btn-success"
                                                                           value="Add to Cart">
                                </div>
                         </form>
                     </div>
                     <?php
                       
                       }

                     }
                    ?>
                    
                 </div>

            </div>

        </div>
    </div>
</section>

<?php }else{ header('location:login.php');} ?>
<?php include 'template/footer.php' ?>