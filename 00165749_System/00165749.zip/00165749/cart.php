<?php include 'template/header.php' ?>
<?php include 'template/navbar.php' ?>
<?php  if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == 0) { ?>
<?php   if (isset($_GET["action"])){
        if ($_GET["action"] == "delete"){
            foreach ($_SESSION["cart"] as $keys => $value){
                if ($value["product_id"] == $_GET["id"]){
                    unset($_SESSION["cart"][$keys]);
                    echo '<script>alert("Product has been Removed...!")</script>';
                    echo '<script>window.location="Cart.php"</script>';
                }
            }
        }
    } ?>
   
<section id="container" class="sub-page">
    <div class="wrap-container zerogrid">
        <div class="crumbs">
         <ul>
           <li><a href="index.php">Home</a></li>
           <li><a href="menu.php">Menu</a></li>
         </ul>
      </div>
        <div id="main-content">    
            <div class="container">

            <div style="clear: both"></div>
                    <h3 class="title2" style="text-align: center;"> Cart Details</h3>
                    <form action="order_confirm.php" method="post" >
                    <div class="table-responsive">
                        
                        <table class="table table-bordered">
                        <tr>
                            <th width="10%">Product id</th>
                            <th width="20%">Product Name</th>
                            <th width="10%">Quantity</th>
                            <th width="13%">Price Details</th>
                            <th width="10%">Total Price</th>
                            <th width="15%">Remove Item</th>
                        </tr>

                        <?php
                            if(!empty($_SESSION["cart"])){
                                $total = 0;
                                foreach ($_SESSION["cart"] as $key => $value) {
                                    ?>
                                    <tr>
                                        <td><?php echo $value["product_id"]; ?></td>
                                        <input type="hidden" name="product_id" value="<?php echo $value['product_id']; ?>">
                                        <td><?php echo $value["item_name"]; ?></td>
                                        <td><?php echo $value["item_quantity"]; ?></td>
                                        <input type="hidden" name="item_quantity" value="<?php echo $value['item_quantity']; ?>">
                                        <td>$ <?php echo $value["product_price"]; ?></td>
                                        <input type="hidden" name="product_price" value="<?php echo $value['product_price']; ?>">
                                        <td>
                                            $ <?php echo number_format($value["item_quantity"] * $value["product_price"], 2); ?></td>
                                        <td><a href="cart.php?action=delete&id=<?php echo $value["product_id"]; ?>"><span
                                                    class="text-danger">Remove Item</span></a></td>

                                    </tr>

                                    <?php
                                    $total = $total + ($value["item_quantity"] * $value["product_price"]);
                                
                                    ?>
                                    <input type="hidden" name="total" value="<?php echo $total; ?>">
                                    <?php } ?>
                                    <tr>
                                        <td colspan="4" align="right">Total</td>
                                        <th align="right">$ <?php echo number_format($total, 2); ?></th>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" align="right"></td>
                                      
                                        <td>  <input type="submit" value="Confirm" name="c_confirm"/> </td>
                                    </tr>
                                    <?php
                                }
                            ?>
                        </table>

                        
                    </div>
                    </form>
            </div>
    <!-- /.container -->
        </div>
    </div>
</section>
<?php }else{ header('location:login.php');} ?>

<?php include 'template/footer.php' ?>