<?php include 'template/header.php'; ?>
<?php include 'template/navbar.php'; ?>
<?php  if(isset($_SESSION['user_role'])) { ?>
	<?php
		include_once 'db.php';
		
		$id = $_SESSION['user_id'];
		
		if($_POST){
			$name = $_POST['user_name'];
			$pass = $_POST['pass'];
			$sql = "UPDATE users SET name='$name',password='$pass' WHERE id=$id";
			$con->query($sql);
		}
		
		$sql = "SELECT * FROM users WHERE id=$id";
		$result = $con->query($sql);
		foreach($result AS $row){
			$name = $row['name'];
			$email = $row['email'];
			$pass = $row['password'];
			$_SESSION['user_name'] = $row['name'];
		}
	?>
	
    <!-- Navigation -->

<section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		 <div class="crumbs">
	      <ul>
	        <li><a href="index.php">Home</a></li>
	        <li><a href="userProfile.php"><?=$_SESSION['user_name']?></a></li>
	      </ul>
  		</div>
  		
		<div id="main-content">

  <!-- Page Content -->
		    <div class="container">

		      <div class="row">

		        
				
		        <div class="col-lg-12">
		        	<div class="col-lg-4"></div>
					<div class="col-lg-5 kkk">
				
					<form action="" method="POST" id="register">
						<div class="form-group">
							<label for="user_name">Name</label>
							<input type="text" name="user_name" value="<?=$name?>" class="form-control" id="user_name" placeholder="Name">
						</div>
					  <div class="form-group">
							<label for="email">Email</label>
							<input type="email" name="email" value="<?=$email?>" class="form-control" id="email" placeholder="Email" readonly>
						</div>
						<div class="form-group">
							<label for="pass">Password</label>
							<input type="password" name="pass" value="<?=$pass?>" class="form-control" id="pass" placeholder="Password">
						</div>
						<div class="form-group">
							<label for="rpass">Re-Password</label>
							<input type="password" name="rpass" class="form-control" id="rpass" placeholder="Re-Password">
						</div>
					
					  
					  <button type="submit" class="btn btn-primary submit-btn">Submit</button>
				</form>
				<script>
					$('.submit-btn').click(function(){
						var name = $('#user_name').val();
						if(name == ''){
							$('#user_name').addClass('is-invalid');
							return false;
						}else{
							$('#user_name').removeClass('is-invalid');
							$('#user_name').addClass('is-valid');
						}
					});
				</script>
		     
					</div>

					<!-- /.col-lg-6 -->
					<div class="col-lg-7">
						<?php //include 'register.php'; ?>
					</div>
		        </div>
		        <!-- /.col-lg-9 -->
		      </div>
		      <?php }else{ echo 'Hahahah!! Funny man...';} ?>
		      <!-- /.row -->
		    
		    <!-- /.container -->
		    </div>



		</div>
	</div>
</section>

  
    <!-- Footer -->
	<?php include 'template/footer.php'; ?>