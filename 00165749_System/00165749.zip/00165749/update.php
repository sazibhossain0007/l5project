<?php include 'template/header.php' ?>
<?php include 'template/navbar.php' ?>
<?php include 'template/slider.php' ?>
<?php include_once 'db.php'; ?>

<?php 
$id=$_GET['id'];
$status=$_GET['status'];
$sql="UPDATE `order_details` SET`order_status`='$status' where order_id=$id";
$result = $con->query($sql);

header('location:index.php');

?>


<?php include 'template/footer.php' ?>








