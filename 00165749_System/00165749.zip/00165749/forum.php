	
<?php include 'template/header.php'; ?>
<?php include 'template/navbar.php'; ?>
    
	<?php  if(isset($_SESSION['user_role'])) { ?>
	<?php 
		include_once 'db.php';
		
		
		if(isset($_POST['forum_post'])){
			
			$msg = '';
			if(isset($_POST['title']) && $_POST['title'] != '')
				$title = $_POST['title'];
			else $msg .='Your post must have a title</br>';
			
			if(isset($_POST['description']) && $_POST['description'] != '')
				$description = $_POST['description'];
			else $msg .='Your post must have a description</br>';
			
			
			
			if($msg == ''){
				$userID = $_SESSION['user_id'];
				$postDate = date('Y-m-d H:i:s'); 
				$sql = "INSERT INTO forum_post(`title`,`description`,`post_date`,`user_id`)
						VALUES ('$title','$description','$postDate',$userID)";
						
				if($con->query($sql)){
					echo '<h3 style="color:green; text-align:center;">post successfull</h3>';
				}
			}
		}
		
		else if(isset($_POST['forum_comment'])){
			
			$msg = '';
			if(isset($_POST['comment']) && $_POST['comment'] != '')
				$comment = $_POST['comment'];
			else $msg .='Your post must have a comment</br>';
			
			if($msg == ''){
				$postId = $_POST['post_id'];
				$userID = $_SESSION['user_id'];
				$postDate = date('Y-m-d H:i:s'); 
				$sql = "INSERT INTO forum_comment(`description`,`post_date`,`user_id`,`post_id`)
						VALUES ('$comment','$postDate',$userID,$postId)";
						
				if($con->query($sql)){
					echo 'Comment successfull';
				}
			}
		}
		
		$sql = 'SELECT * FROM forum_post';
		$posts = $con->query($sql);
	?>
	
    <!-- Page Content -->

<section id="container" class="sub-page">
   <div class="wrap-container zerogrid">
      <div class="crumbs">
         <ul>
           <li><a href="index.php">Home</a></li>
           <li><a href="forum.php">forum</a></li>
         </ul>
      </div>
      <div id="main-content">
			<div class="container">

			    <div class="row">

			       <div class="col-lg-2"></div>
			        <div class="col-lg-8">
					<div class="row">
						<form action="" method="POST" enctype="form-data">
							<div class="form-group">
								<label for="title">Title</label>
								<input type="text" name="title" class="form-control" >
							</div>
							<div class="form-group">
								<label for="description">Description</label>
								<textarea name="description" class="form-control"></textarea>
							</div>
							<button type="submit" name="forum_post" class="btn btn-primary">Post</button><br><br>
						</form>
						</div>




						<div class="row">
						<?php foreach($posts AS $post){ ?>
						<div class="col-lg-12">
							<h2><?=$post['title']?></h2>
							<p><?=$post['description']?></p>

							<form action="" method="POST">
								<input name="post_id" type="hidden" value="<?=$post['id']?>"> 
							
								<textarea name="comment" class="form-control" style="height:75px; width:315px;"></textarea>
							

								<button type="submit" name="forum_comment" class="btn btn-primary">Comment</button><br><br>
							</form>
							
						</div>
						<div class="col-lg-8">
							<?php 
							$p_id=$post['id'];
								$sql1 = "SELECT u.name,fc.id, fc.description from users u, forum_comment fc where u.id = fc.user_id AND fc.post_id=$p_id";
								$comments = $con->query($sql1);

								foreach($comments AS $comment){ ?>
								<p><?=$comment['description']?></p>
								Commanded by:<?php echo $comment['name']; ?>
								<br>
								
								<a style="color:red;" href="delete.php?id=<?=$comment['id']?>">Delete </a><br><br>
							<?php } ?>
						</div>	
						<?php } ?>
						
						</div>
						
			        </div>
			        <!-- /.col-lg-9 -->
			      </div>
			      <!-- /.row -->
			     
			    </div>
			    <!-- /.container -->
			</div>
		</div>
	</section>
<?php }else{ header('location:login.php');} ?>

    <!-- Footer -->
	<?php include 'template/footer.php'; ?>