	
	<?php include 'template/header.php'; ?>
    <!-- Navigation -->
    
    <?php include 'template/navbar.php'; ?>
   
    
<section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		<div class="crumbs">
         <ul>
           <li><a href="index.php">Home</a></li>
           <li><a href="login.php">Log in</a></li>
         </ul>
      </div>
		<div id="main-content">


<div class="regform">

    <!-- Page Content -->
    <div class="container ">

      <div class="row">

        
        <!-- /.col-lg-3 -->
	
        <div class="col-lg-12 reg">
        	<div class="col-lg-2"></div>

			<div class="col-lg-4 ">
			<h2>Fill up your information</h2>
			<form class="needs-validation frm" novalidate action="" method="POST">
				<?php include 'register.php'; ?>
				<div class="form-group name">
					<label for="user_name">Name *</label>
					<input type="text" name="user_name" class="form-control" id="user_name" placeholder="Name">
					<p class="name-error hide" style="color:red">Please type your name</p>
				</div>

			  <div class="form-group">
				<label for="phone">Phone *</label>
				<input type="text" class="form-control" name="phone" id="phone" placeholder="Phone">
				<p class="phone-error hide" style="color:red">Please type your phone</p>
			  </div>
			  
			  <div class="form-check">
				  <input class="form-check-input" type="radio" name="gender" id="gender" value="male" checked>
				  <label class="form-check-label" for="gender">
					Male
				  </label>
			</div>
			<div class="form-check">
				  <input class="form-check-input" type="radio" name="gender" id="gender" value="female">
				  <label class="form-check-label" for="gender">
					Female
				  </label>
			</div>
			<div class="form-check">
				  <input class="form-check-input" type="radio" name="gender" id="gender" value="others">
				  <label class="form-check-label" for="gender">
					Others
				  </label>
				  

			</div>	
			<br>
			  
				  <div class="form-group">
					<label for="email">Email *</label>
					<input type="email" name="email" class="form-control" id="email" placeholder="Email">
					<p class="email-error hide" style="color:red">Please type your email</p>
				</div>

				<div class="form-group">
					<label for="postal">Postal Address *</label>
					<input type="text" name="postal" class="form-control" id="postal" placeholder="Postal Address">
					<p class="postal-error hide" style="color:red">Please type your postal address</p>
				</div>

				<div class="form-group">
					<label for="pcode">Post Code *</label>
					<input type="text" name="pcode" class="form-control" id="pcode" placeholder="Post Code">
					<p class="pcode-error hide" style="color:red">Please type your phone</p>
				</div>
				<div class="form-group">
					<label for="pass">Password *</label>
					<input type="password" name="pass" class="form-control" id="pass" placeholder="Password">
					<p class="pass-error hide" style="color:red">Please type your password</p>
				</div>
				<div class="form-group">
					<label for="rpass">Re-Password *</label>
					<input type="password" name="rpass" class="form-control" id="rpass" placeholder="Re-Password">
					<p class="rpass-error hide" style="color:red">Please re type your password</p>
				</div>
			
			  
			  <button type="submit" onclick="return formValidate();" class="btn btn-primary submit-btn button" style="margin: auto;" >Submit</button>
		</form>
     
			</div>
			<!-- /.col-lg-6 -->
			
        </div>
        <!-- /.col-lg-9 -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container -->
    </div>

		</div>
	</div>
</section>



    


	<script>
			function formValidate(){
				
				if($('#user_name').val() == ''){
					$('.name-error').removeClass('hide');
					returnResult = false;
				}else{
					$('.name-error').addClass('hide');
					returnResult = true;
				}
				if($('#phone').val() == ''){
					$('.phone-error').removeClass('hide');
					returnResult = false;
				}else{
					$('.phone-error').addClass('hide');
					returnResult = true;
				}

				

				if($('#email').val() == ''){
					$('.email-error').removeClass('hide');
					returnResult = false;
				}else{
					$('.email-error').addClass('hide');
					returnResult = true;
				}

				if($('#postal').val() == ''){
					$('.postal-error').removeClass('hide');
					returnResult = false;
				}else{
					$('.postal-error').addClass('hide');
					returnResult = true;
				}

				if($('#pcode').val() == ''){
					$('.pcode-error').removeClass('hide');
					returnResult = false;
				}else{
					$('.pcode-error').addClass('hide');
					returnResult = true;
				}

				if($('#pass').val() == ''){
					$('.pass-error').removeClass('hide');
					returnResult = false;
				}else{
					$('.pass-error').addClass('hide');
					returnResult = true;
				}

				if($('#rpass').val() == ''){
					$('.rpass-error').removeClass('hide');
					returnResult = false;
				}else{
					$('.rpass-error').addClass('hide');
					returnResult = true;
				}

				return returnResult;
			}
		
	</script>


    <!-- Footer -->
	<?php include 'template/footer.php'; ?>