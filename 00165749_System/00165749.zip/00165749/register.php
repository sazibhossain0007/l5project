<?php
	$flag = true;
	if($_POST){
		if(isset($_POST['user_name']) && $_POST['user_name'] != ''){
			$userName = $_POST['user_name'];
		}else{

			$flag = false;
		}
		
		if(isset($_POST['phone']) && $_POST['phone'] != ''){
			$phone = $_POST['phone'];
		}else{
			
			$flag = false;
		}
		
		if(isset($_POST['gender']) && $_POST['gender'] != ''){
			$gender = $_POST['gender'];
		}else{
			
			$flag = false;
		}
		
		if(isset($_POST['email']) && $_POST['email'] != ''){
			$email = $_POST['email'];
		}else{
			
			$flag = false;
		}

		if(isset($_POST['postal']) && $_POST['postal'] != ''){
			$postal = $_POST['postal'];
		}else{
			
			$flag = false;
		}

		if(isset($_POST['pcode']) && $_POST['pcode'] != ''){
			$pcode = $_POST['pcode'];
		}else{
			
			$flag = false;
		}



		
		
		if(isset($_POST['pass']) && $_POST['pass'] != ''){
			if(isset($_POST['rpass']) && $_POST['rpass'] != ''){
				if($_POST['pass'] == $_POST['rpass']){
					$pass = $_POST['pass'];
				}else{
					echo '<h4 style="color:red">Password didn\'t match</h4><br>';
					$flag = false;
				}
			}else{
				
				$flag = false;
			}
			
		}else{
			
			$flag = false;
		}
		
		if($flag){
			
			include_once('db.php');
			
			$sql  = "SELECT * FROM `users` WHERE `email`='$email'";
			$result = $con->query($sql);
			if($result->num_rows > 0){
				echo '<h4 style="color:red">Email already exist</h4><br>';
			}else{
				$sql  = "INSERT INTO `users` (`name`, `email`,`postal_address`,`post_code`,`password`) 
									VALUES ('$userName', '$email','$postal','$pcode','$pass')";
				if($con->query($sql)){
					echo '<h3 style="color:green">User Created successfully</h3>';
				}else{
					echo 'User not created';
				}
			}
			
		}
	}
?>
